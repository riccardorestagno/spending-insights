# Profiles — changed and added files

Copy the contents of this folder over your `spending-insights-main` checkout,
keeping the paths as they are. Nothing else in the project needs to change, and
no new dependencies are required.

Restart the server once after copying: the new tables and the `profile_id`
column are created on startup, and any transactions already in the database are
moved into a profile named `Default`.

## Added

| File | What it does |
| ---- | ------------ |
| `server/db/profiles.py` | Reading and writing the `profiles` table, plus name validation |
| `server/api/routes/profiles.py` | `GET/POST /profiles`, `PATCH/DELETE /profiles/{id}` |
| `server/schemas/profile.py` | Request and response models for the above |
| `client/src/contexts/ProfileContext.tsx` | Holds the profile list and which one is selected |
| `client/src/components/ProfileSwitcher/ProfileSwitcher.tsx` | Header dropdown: switch, create, rename, delete |
| `client/src/components/ProfileSwitcher/ProfileNameDialog.tsx` | Shared naming dialog for create and rename |
| `client/src/components/ProfileSwitcher/DeleteProfileDialog.tsx` | Confirmation before a profile and its rows go |
| `client/src/utils/api.ts` | `fetch` + FastAPI error unpacking, shared by the new calls |

## Modified

| File | Change |
| ---- | ------ |
| `server/db/database.py` | Creates the `profiles` table and the `transactions.profile_id` column; adopts pre-profile rows into `Default` |
| `server/db/loaders.py` | Loads into a given profile; duplicate detection is scoped to that profile |
| `server/api/routes/load_csv.py` | `/load-csv` and `/upload-csv` take `profile_id` or `profile_name`, and report the profile they wrote to |
| `server/api/routes/transactions.py` | Optional `profile_id` filter; the column is returned with each transaction |
| `server/api/routes/categories.py` | Optional `profile_id` filter on the counts and totals |
| `server/api/routes/export_csv.py` | Optional `profile_id` filter; the profile name leads the download filename |
| `server/api/routes/__init__.py`, `server/main.py` | Register the profiles router |
| `server/schemas/transaction.py` | Adds `profile_id` |
| `client/src/App.tsx` | Wraps the dashboard in `ProfileProvider`; category totals follow the profile |
| `client/src/components/TransactionViewer/TransactionViewer.tsx` | Every request is scoped to the profile; empty-database state; a 404 now reads as "no rows" rather than an error |
| `client/src/components/TransactionViewer/Header.tsx` | Shows the switcher and names the profile on screen |
| `client/src/components/TransactionViewer/types.ts` | Adds the `Profile` type |
| `client/src/components/UploadCsv/UploadCsvDialog.tsx` | Choose the destination profile, or name a new one |
| `client/src/components/UploadCsv/UploadCsv.tsx` | Sends the destination and switches to it afterwards |
| `client/src/components/ExportCsv/ExportCsv.tsx` | Exports only the selected profile |
| `client/src/components/InsightsPanel/InsightsPanel.tsx`, `client/src/hooks/useTransactions.ts` | Charts read the selected profile only |
| `README.md` | Documents profiles and the new endpoints |

## Why a separate table

Transactions store `profile_id` and never the name, so renaming a profile is a
one-row `UPDATE profiles SET name = ?`. No transaction row is rewritten, and
nothing that references a profile has to be migrated when the name changes.
