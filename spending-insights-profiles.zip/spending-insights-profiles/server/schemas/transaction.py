from pydantic import BaseModel
from typing import List, Optional

from models.enums import CategoryOut


class Transaction(BaseModel):
    id: int
    account_type: str
    account_number: str
    transaction_date: str
    cheque_number: Optional[str]
    description_1: str
    description_2: Optional[str]
    cad_amount: float
    usd_amount: Optional[float]
    category: CategoryOut
    is_reimbursed: bool = False
    # Nullable only for rows that predate profiles and haven't been adopted yet
    profile_id: Optional[int] = None


class PaginatedResponse(BaseModel):
    data: List[Transaction]
    metadata: dict
