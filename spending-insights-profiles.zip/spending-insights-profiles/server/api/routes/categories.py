import sqlite3
from fastapi import APIRouter, Query
from typing import Optional

from db.database import connect
from models.enums import Category, TransactionType

router = APIRouter()


@router.get("/categories")
async def get_categories(
        profile_id: Optional[int] = Query(
            None,
            description="Only count transactions in this profile. Omit for every profile.",
        ),
        start_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
        end_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
        transaction_type: TransactionType = Query(TransactionType.DEBIT, description="Filter by transaction type"),
):
    conn = connect()
    cursor = conn.cursor()

    where_conditions = []
    params = []

    if profile_id is not None:
        where_conditions.append("profile_id = ?")
        params.append(profile_id)

    if start_date:
        where_conditions.append("transaction_date >= ?")
        params.append(start_date)

    if end_date:
        where_conditions.append("transaction_date <= ?")
        params.append(end_date)

    if transaction_type == TransactionType.DEBIT:
        where_conditions.append("cad_amount < 0")
    elif transaction_type == TransactionType.CREDIT:
        where_conditions.append("cad_amount > 0")

    where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"

    cursor.execute(
        f"""
            SELECT category, COUNT(*) AS count, SUM(cad_amount) AS total
            FROM transactions
            WHERE {where_clause}
            GROUP BY category
            ORDER BY category
        """,
        params,
    )

    results = cursor.fetchall()
    conn.close()

    categories = [
        {
            "value": row[0],
            "description": Category(row[0]).description,
            "transaction_count": row[1],
            "total": round(row[2], 2),
        }
        for row in results
    ]

    all_transactions = {
        "value": Category.ALL,
        "description": Category.ALL.description,
        "transaction_count": sum(category["transaction_count"] for category in categories),
        "total": sum(category["total"] for category in categories),
    }

    categories.insert(0, all_transactions)

    return {
        "categories": categories
    }
