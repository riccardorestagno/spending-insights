/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Overrides the API origin; normally unset so the app uses /api. */
  readonly VITE_API_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
