/**
 * Where the API lives, from the browser's point of view.
 *
 * Relative by default. In Docker, nginx serves this app and reverse-proxies
 * /api to the backend, so the app and the API share one origin and the browser
 * never needs the server's address. That is the point: an absolute
 * http://localhost:8000 would resolve to whichever phone or laptop is *viewing*
 * the page, not to the machine running the stack.
 *
 * Outside Docker, `yarn dev` proxies /api the same way (see vite.config.js), so
 * this value is correct in both environments without a rebuild. Set
 * VITE_API_BASE_URL only to point at an API somewhere else entirely.
 */
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '/api';
