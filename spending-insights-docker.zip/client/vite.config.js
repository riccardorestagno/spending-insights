import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // Lets other devices reach the dev server, matching how the Docker build
    // behaves. Without it Vite binds to localhost only.
    host: true,
    // Mirrors the nginx rule in client/nginx.conf, so the client code can call
    // a relative /api in development and in Docker alike.
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
