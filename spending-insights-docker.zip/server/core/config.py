import os

# Overridable so the container can point at its mounted volume. The default
# keeps `python main.py` working exactly as before outside Docker.
#
# api/routes/load_csv.py derives the upload directory from this path, so
# changing it moves the saved CSVs along with the database.
DB_PATH = os.environ.get("DB_PATH", "data/transactions.db")
