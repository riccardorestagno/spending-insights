# Running Spending Insights on your home network

This runs the whole app in Docker on a Windows machine and makes it reachable
from any device on your Wi-Fi at `http://spending-insights.home`.

- [How it fits together](#how-it-fits-together)
- [Part 1 — Get it running on the machine](#part-1--get-it-running-on-the-machine)
- [Part 2 — Reach it from other devices](#part-2--reach-it-from-other-devices)
- [Part 3 — Give it a name](#part-3--give-it-a-name)
- [Part 4 — Keep it running](#part-4--keep-it-running)
- [Day-to-day commands](#day-to-day-commands)
- [Backups](#backups)
- [Troubleshooting](#troubleshooting)
- [Adding more apps later](#adding-more-apps-later)

## How it fits together

Two containers, one published port:

```
        phone / laptop / tablet on the Wi-Fi
                       |
                 http://spending-insights.home
                       |
        [ Windows machine :80 ]
                       |
              +--------+--------+
              |   web (nginx)   |   serves the built React app
              +--------+--------+
                       |  /api/*  -> proxied internally
              +--------+--------+
              | server (FastAPI)|   never exposed to the network
              +--------+--------+
                       |
                 db-data volume     transactions.db + saved uploads
```

Everything is on one origin. That detail matters more than it looks: the
frontend used to call `http://localhost:8000` directly, which works only when
the browser is on the same machine as the API. From your phone, `localhost` is
*the phone*. The app now calls a relative `/api`, and nginx forwards it, so it
works identically from any device.

## Part 1 — Get it running on the machine

**1. Install Docker Desktop.** Get it from docker.com and choose the **WSL 2
backend** when asked (the default). Windows 10 or 11, Home or Pro, all fine.
Reboot if it asks.

**2. Open a terminal in the project folder.** PowerShell is fine.

```powershell
cd path\to\spending-insights
```

**3. Optionally set a port.** Only needed if something already uses port 80:

```powershell
copy .env.example .env
notepad .env
```

**4. Build and start.**

```powershell
docker compose up -d --build
```

First build takes a few minutes — it installs pandas and builds the frontend.
Later builds are much faster.

**5. Check it.** Open <http://localhost> on that machine. You should see the
app. If you have no data yet, upload a categorized CSV with the **Upload CSV**
button.

The interactive API docs are at <http://localhost/api/docs>.

## Part 2 — Reach it from other devices

**1. Give the machine a fixed address.** Its IP must stop changing or the name
you set up in Part 3 will break. Two ways, pick one:

- **Better — a DHCP reservation on your router.** Find your router's admin page
  (usually `http://192.168.1.1` or `http://192.168.0.1`), look for *DHCP
  Reservations* / *Static Leases* / *Address Reservation*, and pin the
  machine's current IP to it. This keeps Windows on automatic settings, so
  nothing breaks if you move the machine to another network.
- **Or — a static IP in Windows.** Settings → Network & Internet → your
  adapter → *IP assignment* → Edit → Manual. Pick an address outside your
  router's DHCP pool.

Find the current IP with:

```powershell
ipconfig
```

Use the **IPv4 Address** of the adapter you're actually connected through —
`Wireless LAN adapter Wi-Fi` or `Ethernet`. Ignore anything labelled WSL,
vEthernet, Hyper-V, or Docker. Say it's `192.168.1.50`.

**2. Allow it through Windows Firewall.** Docker Desktop usually adds a rule,
but if other devices can't connect this is nearly always why. In an
**Administrator** PowerShell:

```powershell
New-NetFirewallRule -DisplayName "Spending Insights (HTTP 80)" `
  -Direction Inbound -Protocol TCP -LocalPort 80 `
  -Action Allow -Profile Private
```

`-Profile Private` restricts it to networks Windows considers private. If it
still doesn't work, confirm your Wi-Fi is set to **Private** and not **Public**
under Settings → Network & Internet → Wi-Fi → your network.

**3. Test from your phone.** Turn Wi-Fi on, visit `http://192.168.1.50`. Once
that works, the name in Part 3 is the only thing left.

## Part 3 — Give it a name

`spending-insights.home` has to resolve to `192.168.1.50` on each device that
uses it. There is no way around configuring *something* — the options differ in
how many places you have to touch.

### Option A — A DNS entry on your router (best, if supported)

One entry, every device on the network gets it, including phones. Look in the
router admin for *DNS*, *Static DNS*, *Local DNS*, *Host Names*, *DNS Host
Mapping*, or *Address Reservation with hostname*. Add:

| Hostname | Address |
| --- | --- |
| `spending-insights.home` | `192.168.1.50` |

Support varies a lot. Most ISP-supplied routers can't do it. OpenWrt, pfSense,
OPNsense, UniFi, ASUS with Merlin firmware, and some Netgear/TP-Link models
can. If yours can't, use Option B.

### Option B — A DNS server of your own (best if you'll add more apps)

Run **AdGuard Home** or **Pi-hole** on your network, point your router's DHCP
at it as the DNS server, and add a rewrite. This is the option that scales, and
it's what I'd suggest given your third requirement — see
[Adding more apps later](#adding-more-apps-later) for the wildcard setup that
means you never touch DNS again for a new app.

One important caveat if you run it in Docker on this same Windows machine: it
needs UDP port 53, and Docker Desktop's port forwarding for UDP has historically
been unreliable. A cheap Raspberry Pi, or an old machine, is a more dependable
home for DNS than Docker Desktop on Windows. If DNS is running on Windows,
also make sure the Windows machine isn't set to use *itself* for DNS, or a
container restart takes your whole network's internet with it.

### Option C — A hosts file entry per device (works right now, doesn't scale)

Fine for two or three computers. Not practical for phones or tablets, which
generally can't be edited without rooting/jailbreaking.

On **Windows**, open Notepad *as Administrator*, open
`C:\Windows\System32\drivers\etc\hosts`, and add:

```
192.168.1.50    spending-insights.home
```

On **macOS/Linux**: the same line in `/etc/hosts` via
`sudo nano /etc/hosts`.

Then flush the cache — `ipconfig /flushdns` on Windows.

### A note on `.home`

`.home` works in practice and reads nicely, so the config here accepts any
hostname and nothing needs to change if you keep it. Two things to know:

- It isn't formally reserved. ICANN considered delegating `.home` as a real
  public TLD; that's currently stalled, but if it ever ships, a name you use
  privately could start resolving publicly. **`.home.arpa`** is the name
  reserved by [RFC 8375](https://www.rfc-editor.org/rfc/rfc8375.html) for
  exactly this, so `spending-insights.home.arpa` is the future-proof choice if
  you don't mind the extra typing.
- Don't use **`.local`**. It's reserved for mDNS/Bonjour, and putting it in a
  normal DNS server causes genuinely confusing, intermittent failures.

Either way, type `http://` explicitly the first time. Some browsers try HTTPS
first on an unfamiliar name and show a warning before falling back.

## Part 4 — Keep it running

`restart: unless-stopped` in the compose file restarts the containers if they
crash or if Docker restarts. Two things it can't do for you:

**Start Docker Desktop on login.** Docker Desktop → Settings → General → tick
*Start Docker Desktop when you sign in*. Note the containers come up when
someone **signs in**, not at boot. For a true always-on server you'd want
Docker Engine on a Linux box instead; on Windows, staying signed in is the
practical answer.

**Stop the machine sleeping.** A sleeping laptop serves nothing. Settings →
System → Power → set *Screen and sleep* to Never when plugged in. On a laptop,
also check the lid-close action.

## Day-to-day commands

Run these from the project folder.

```powershell
docker compose up -d              # start
docker compose down               # stop (data is kept)
docker compose restart            # restart
docker compose logs -f            # follow logs, Ctrl+C to stop watching
docker compose logs -f server     # just the API
docker compose ps                 # what's running and healthy
```

After changing code, rebuild:

```powershell
docker compose up -d --build
```

To load a CSV from a server-side path, drop it in the `imports/` folder next to
this file — it's mounted read-only inside the container at `/imports`:

```powershell
curl.exe -X POST "http://localhost/api/load-csv?csv_path=/imports/export_categorized.csv&profile_name=Alex"
```

The **Upload CSV** button in the app does the same thing through the browser
and doesn't need the folder at all.

## Backups

Your data is in a Docker named volume, not in the project folder, so copying
the folder does **not** back it up. To write a copy into `.\backups`:

```powershell
mkdir backups -Force
docker run --rm -v spending-insights_db-data:/data -v "${PWD}\backups:/backup" `
  alpine tar czf /backup/spending-insights-$(Get-Date -Format yyyy-MM-dd).tar.gz -C /data .
```

To restore into an empty volume:

```powershell
docker compose down
docker run --rm -v spending-insights_db-data:/data -v "${PWD}\backups:/backup" `
  alpine sh -c "rm -rf /data/* && tar xzf /backup/YOUR-BACKUP.tar.gz -C /data"
docker compose up -d
```

You can also just export a CSV from the app now and then, which is a readable
backup of the transactions themselves.

## Troubleshooting

**Other devices can't connect, but `localhost` works.** Firewall first (Part 2
step 2), then check the Wi-Fi is a *Private* network, then confirm you used the
Wi-Fi/Ethernet IPv4 address rather than a WSL or vEthernet one.

**`ports are not available` / `address already in use` on startup.** Something
owns port 80. Find it:

```powershell
netstat -ano | findstr ":80 "
```

Then either stop it or set `HTTP_PORT=8080` in `.env` — the URL becomes
`http://spending-insights.home:8080`.

**The name doesn't resolve but the IP works.** DNS. Re-check Part 3, then
`ipconfig /flushdns`. Phones often need Wi-Fi toggled off and on to pick up a
changed DNS server.

**`502 Bad Gateway`.** nginx is up but the API isn't. `docker compose logs
server` will say why.

**The app loads but every request fails.** Check the browser's network tab. The
requests should go to `/api/...` on the same host. If you see `localhost:8000`,
an old bundle is cached — hard-reload, and rebuild with
`docker compose up -d --build`.

**`pip` errors about invalid characters during build.** `requirements.txt` was
UTF-16 encoded (PowerShell's `>` does that) and has been converted to UTF-8. If
you regenerate it, use:

```powershell
pip freeze | Out-File -Encoding utf8 requirements.txt
```

**Permission errors writing the database.** The container runs as a non-root
user that owns `/data` when the volume is first created. If you had it running
as root before, reset the volume — this deletes the data, so export first:

```powershell
docker compose down -v
docker compose up -d --build
```

## Adding more apps later

You said other apps will want this same treatment. Nothing here blocks that,
but two things become awkward once there's a second app: only one container can
own port 80, and adding a DNS entry per app gets tedious.

The standard fix is **one shared reverse proxy plus wildcard DNS**. Do it when
you add the second app, not now.

**1. Wildcard DNS, once.** In AdGuard Home or Pi-hole, point `*.home` at the
machine's IP. Every future app gets a working name with zero DNS work —
`budget.home`, `photos.home`, `notes.home` all just resolve.

**2. One proxy owns port 80.** Run [Caddy](https://caddyserver.com/) or
[Traefik](https://traefik.io/) as the only container publishing 80/443. It
routes by the `Host` header, so it can tell `spending-insights.home` from
`budget.home` and send each to the right container. Caddy is easier to read;
Traefik configures itself from Docker labels, so apps declare their own
hostname and the proxy needs no edits.

**3. Apps stop publishing ports.** Each app joins a shared Docker network and
the proxy reaches it internally. For this app that means:

```yaml
# docker-compose.yml, when you migrate
services:
  web:
    # ports:                      <- delete; the shared proxy owns 80 now
    #   - "${HTTP_PORT:-80}:80"
    networks: [edge]
    labels:
      - traefik.enable=true
      - traefik.http.routers.spending.rule=Host(`spending-insights.home`)
      - traefik.http.services.spending.loadbalancer.server.port=80

networks:
  edge:
    external: true                # created once: docker network create edge
```

That's the whole migration for this app — delete four lines, add a network and
some labels. The nginx config needs no change, because it already accepts any
hostname and keeps the app and its API on a single origin.

**A pattern worth copying to the other apps.** The things that make this one
work aren't specific to it:

- The frontend calls a **relative** API path, never a hostname. This is the
  single biggest cause of "works on my machine, broken on my phone".
- **SQLite lives on a named volume**, never a bind mount to a Windows folder.
  Windows paths reach the container over a filesystem whose locking SQLite
  can't depend on.
- **One origin per app**, so there's no CORS configuration to get wrong and no
  second port to open.
- `restart: unless-stopped` plus a healthcheck, so the stack heals itself.

**If you outgrow Windows.** The real constraint here is that Docker Desktop
needs a signed-in user. If this becomes something you rely on, moving to a
small always-on Linux box — a Raspberry Pi 5, a mini PC, an old laptop — gets
you boot-time startup, proper `systemd` supervision, and DNS you can trust on
port 53. Every file in this setup transfers unchanged; only the host-side steps
in Parts 1 and 4 differ.
