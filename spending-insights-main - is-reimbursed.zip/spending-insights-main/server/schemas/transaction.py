from pydantic import BaseModel
from typing import List, Optional

from models.enums import CategoryOut


class Transaction(BaseModel):
    id: int
    account_type: str
    account_number: str
    transaction_date: str
    cheque_number: Optional[str]
    description_1: str
    description_2: Optional[str]
    cad_amount: float
    usd_amount: Optional[float]
    category: CategoryOut
    # SQLite stores this as 0/1; pydantic coerces it to a real bool for the API
    is_reimbursed: bool = False


class PaginatedResponse(BaseModel):
    data: List[Transaction]
    metadata: dict
